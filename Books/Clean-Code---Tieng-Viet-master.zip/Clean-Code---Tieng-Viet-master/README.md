# Clean Code Tiếng Việt

## Phần 7 - 11 có ở đây: https://github.com/chukimmuoi/Clean-Code---Tieng-Viet

Vui lòng ghi nguồn nếu bạn sử dụng lại bản dịch của mình cho blog của bạn

Bản dịch này hoàn toàn vì cộng đồng, tác giả không chịu trách nhiệm nếu bạn sử dụng cho mục đích thương mại

### Update tháng 09/2023

Repo này đạt 300 sao thì mình sẽ dịch bổ sung các chap còn thiếu & chỉnh sửa lại bản dịch hiện tại cho dễ đọc hơn. Việt Nam nói là nàm!
